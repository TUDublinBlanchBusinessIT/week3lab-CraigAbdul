# Craig Abdul-Kareem
# 17/02/2025
# divisors.py

def divisors(num): 
    
    result = []  

    for i in range(1, +1):  
        if num % i == 0:  
            result.append(i) 

    return result  

print(divisors(30)) 

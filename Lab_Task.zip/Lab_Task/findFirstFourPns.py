# Craig Abdul-Kareem
# 17/02/2025
# findFirstFourPns.py

def is_perfect_number(n):
    
    sum_of_divisors = sum(i for i in range(1, n) if n % i == 0)
    return sum_of_divisors == n

def find_first_four_perfect_numbers():
  
    count = 0
    num = 1
    
    while count < 4:
        if is_perfect_number(num):
            print(f"{num} is a perfect number")
            count += 1
        num += 1

find_first_four_perfect_numbers()
